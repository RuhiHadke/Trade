package com.db.trade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradeApplicationTests {

	@Test
	void contextLoads() {
	}

}
