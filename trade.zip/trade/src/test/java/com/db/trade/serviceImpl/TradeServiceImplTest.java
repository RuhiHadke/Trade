package com.db.trade.serviceImpl;

import com.db.trade.entity.Trade;
import com.db.trade.repository.TradeRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Optional;

import static com.db.trade.constants.ExceptionMessagesConstants.TRADE_REJECTED_MATURITY_DATE_EXCEPTION;
import static com.db.trade.constants.ExceptionMessagesConstants.TRADE_REJECTED_VERSION_EXCEPTION;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

/**
 * @author R.Hadke
 */
@RunWith(SpringRunner.class)
@WebMvcTest(value = TradeServiceImpl.class)
public class TradeServiceImplTest {

    @InjectMocks
    private TradeServiceImpl tradeService;

    @MockBean
    private TradeRepository tradeRepository;

    private Trade trade;

    @Before
    public void setUp() {

        MockitoAnnotations.initMocks(this);
        MockMvcBuilders.standaloneSetup(tradeService).build();

        trade = Trade.builder().tradeId("T1").bookId("B1").counterPartyId("CP-1").expired(false).version(1)._id("606de9731f94e50f5b0a8a00").build();
    }

    @Test
    public void getTradeByTradeId_shouldReturnResponseStatusOK() {
        Mockito.when(tradeRepository.getTradeByTradeId("T1")).thenReturn(trade);
        Optional<Trade> tradeItem = tradeService.getTradeByTradeId("T1");
        tradeItem.ifPresent(value -> assertEquals(trade, value));
    }

    @Test
    public void getTradeByTradeId_shouldReturnResponseStatusAsNull() {
        Mockito.when(tradeRepository.getTradeByTradeId("T1")).thenReturn(null);
        Optional<Trade> tradeItem = tradeService.getTradeByTradeId("T1");
        tradeItem.ifPresent(value -> assertEquals(trade, value));
    }

    @Test
    public void createTrade_shouldReturnResponseStatusOK() throws Exception {
        TradeServiceImpl tradeServiceImpl = mock(TradeServiceImpl.class);
        assertNotNull(tradeServiceImpl);
        Mockito.doCallRealMethod().when(tradeServiceImpl).createTrade(trade);
    }

    @Test
    public void createTrade_shouldThrowTradeRejectedVersionException() throws Exception {
        TradeServiceImpl tradeServiceImpl = mock(TradeServiceImpl.class);
        assertNotNull(tradeServiceImpl);
        Mockito.doThrow(new Exception(TRADE_REJECTED_VERSION_EXCEPTION)).when(tradeServiceImpl).createTrade(trade);
    }

    @Test
    public void createTrade_shouldThrowTradeRejectedMaturityDateException() throws Exception {
        TradeServiceImpl tradeServiceImpl = mock(TradeServiceImpl.class);
        assertNotNull(tradeServiceImpl);
        Mockito.doThrow(new Exception(TRADE_REJECTED_MATURITY_DATE_EXCEPTION)).when(tradeServiceImpl).createTrade(trade);
    }

}
