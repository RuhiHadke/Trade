package com.db.trade.controller;

import com.db.trade.entity.Trade;
import com.db.trade.service.TradeService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.Assert.assertEquals;

/**
 * @author R.Hadke
 */
@RunWith(SpringRunner.class)
@WebMvcTest(value = TradeController.class)
public class TradeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TradeService tradeService;

    @InjectMocks
    private TradeController tradeController;

    private Trade trade;
    private String tradeJsonString;

    @Before
    public void setUp() {

        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(tradeController).build();

        trade = Trade.builder().tradeId("T1").bookId("B1").counterPartyId("CP-1").expired(false).version(1)._id("606de9731f94e50f5b0a8a00").build();
        tradeJsonString = "{\"_id\":\"606de9731f94e50f5b0a8a00\",\"tradeId\":\"T1\",\"counterPartyId\":\"CP-1\",\"bookId\":\"B1\",\"version\":1,\"expired\":false}";
    }

    @Test
    public void createTrade_shouldReturnResponseStatusOK() throws Exception {
        Mockito.when(tradeService.createTrade(trade)).thenReturn(trade);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/trade/create")
                .accept(MediaType.APPLICATION_JSON).content(tradeJsonString).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void getTradeByTradeId_shouldReturnResponseStatusOK() throws Exception {
        Mockito.when(tradeService.getTradeByTradeId("T1")).thenReturn(java.util.Optional.ofNullable(trade));
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/trade/T1")
                .accept(MediaType.APPLICATION_JSON).content(tradeJsonString).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.CREATED.value(), response.getStatus());
    }

    @Test
    public void createTrade_shouldReturnResponseStatusAsNull() throws Exception {
        Mockito.when(tradeService.createTrade(trade)).thenReturn(null);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/trade/create")
                .accept(MediaType.APPLICATION_JSON).content(tradeJsonString).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }

    @Test
    public void getTradeByTradeId_shouldReturnResponseStatusAsNull() throws Exception {
        Mockito.when(tradeService.getTradeByTradeId("T1")).thenReturn(java.util.Optional.empty());
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/trade/T1")
                .accept(MediaType.APPLICATION_JSON).content(tradeJsonString).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }
}
