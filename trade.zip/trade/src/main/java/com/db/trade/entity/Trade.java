package com.db.trade.entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import static com.db.trade.constants.MongoDbConstants.TRADE_COLLECTION;

/**
 * @author R.Hadke
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = TRADE_COLLECTION)
public class Trade {

    @Id
    private String _id;
    private String tradeId;
    private String counterPartyId;
    private String bookId;
    private int version;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate createdDate;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate maturityDate;
    private boolean expired;

}
