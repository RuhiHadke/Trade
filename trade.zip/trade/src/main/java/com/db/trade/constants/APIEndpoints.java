package com.db.trade.constants;

/**
 * @author R.Hadke
 */
public class APIEndpoints {

    public static final String TRADE_API = "/trade";
    public static final String CREATE_TRADE_API = "/create";
    public static final String GET_TRADE_API = "/{tradeId}";
}
