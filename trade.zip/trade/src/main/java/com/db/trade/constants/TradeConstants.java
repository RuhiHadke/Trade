package com.db.trade.constants;

/**
 * @author R.Hadke
 */
public class TradeConstants {

    public static final String SAVE_TRADE = "Saving trade.";
    public static final String GET_TRADE_BY_TRADE_ID = "Getting trade with trade id: ";
    public static final String TRADE_ID = "tradeId";
}
