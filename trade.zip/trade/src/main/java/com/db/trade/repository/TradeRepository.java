package com.db.trade.repository;

import com.db.trade.entity.Trade;
import org.springframework.stereotype.Repository;

/**
 * @author R.Hadke
 */
@Repository
public interface TradeRepository {

    Trade createTrade(Trade trade);

    Trade getTradeByTradeId(String tradeId);
}
