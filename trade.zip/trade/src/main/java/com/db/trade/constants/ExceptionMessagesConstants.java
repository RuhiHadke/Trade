package com.db.trade.constants;

/**
 * @author R.Hadke
 */
public class ExceptionMessagesConstants {

    public static final String TRADE_REJECTED_VERSION_EXCEPTION = "The trade is rejected due to lower version.";
    public static final String TRADE_REJECTED_MATURITY_DATE_EXCEPTION = "The trade is rejected due to less mature date.";
}
