package com.db.trade.repositoryImpl;

import com.db.trade.entity.Trade;
import com.db.trade.repository.TradeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import static com.db.trade.constants.MongoDbConstants.TRADE_COLLECTION;
import static com.db.trade.constants.TradeConstants.TRADE_ID;

/**
 * @author R.Hadke
 */
@Component
public class TradeRepositoryImpl implements TradeRepository {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public Trade createTrade(Trade trade) {
        return mongoTemplate.save(trade, TRADE_COLLECTION);
    }

    @Override
    public Trade getTradeByTradeId(String tradeId) {
        return mongoTemplate.findOne(Query.query(Criteria.where(TRADE_ID).is(tradeId)), Trade.class, TRADE_COLLECTION);
    }
}
