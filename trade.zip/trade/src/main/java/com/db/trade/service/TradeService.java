package com.db.trade.service;

import com.db.trade.entity.Trade;

import java.util.Optional;

/**
 * @author R.Hadke
 */
public interface TradeService {

    Trade createTrade(Trade trade) throws Exception;

    Optional<Trade> getTradeByTradeId(String tradeId);
}
