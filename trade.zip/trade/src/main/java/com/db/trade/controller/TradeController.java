package com.db.trade.controller;

import com.db.trade.entity.Trade;
import com.db.trade.service.TradeService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

import static com.db.trade.constants.APIEndpoints.*;
import static com.db.trade.constants.TradeConstants.*;

/**
 * @author R.Hadke
 */
@Slf4j
@RestController
@RequestMapping(value = TRADE_API)
public class TradeController {

    private Logger logger = LoggerFactory.getLogger(TradeController.class);

    @Autowired
    private TradeService tradeService;

    /**
     * Below API is used to create and update the trade
     *
     * @param trade Input trade entity as parameter
     * @return
     * @throws Exception
     */
    @PostMapping(CREATE_TRADE_API)
    public ResponseEntity<Trade> addNewTrade(@RequestBody Trade trade) throws Exception {
        logger.info(SAVE_TRADE);
        Trade tradeResponse = tradeService.createTrade(trade);
        if (tradeResponse != null) {
            return ResponseEntity.ok(tradeResponse);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(tradeResponse);
    }

    /**
     * Below API is used to get the trade using trade id
     *
     * @param tradeId Input tradeId as the parameter
     * @return
     */
    @GetMapping(value = GET_TRADE_API)
    public ResponseEntity<Optional<Trade>> getTrade(@PathVariable String tradeId) {
        logger.info(GET_TRADE_BY_TRADE_ID, tradeId);
        Optional<Trade> tradeResponse = tradeService.getTradeByTradeId(tradeId);
        if (tradeResponse.isPresent()) {
            return new ResponseEntity<>(tradeResponse, HttpStatus.CREATED);
        }
        return new ResponseEntity<>(tradeResponse, HttpStatus.BAD_REQUEST);
    }
}
