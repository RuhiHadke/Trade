package com.db.trade.serviceImpl;

import com.db.trade.entity.Trade;
import com.db.trade.repository.TradeRepository;
import com.db.trade.service.TradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Optional;

import static com.db.trade.constants.ExceptionMessagesConstants.*;

/**
 * @author R.Hadke
 */
@Service
public class TradeServiceImpl implements TradeService {

    @Autowired
    private TradeRepository tradeRepository;

    @Override
    public Trade createTrade(Trade trade) throws Exception {

        Trade tradeResponse = new Trade();

        // Validation for Created Date
        if (trade.getCreatedDate() == null) {
            trade.setCreatedDate(LocalDate.now());
        }

        // Validation for Version
        Trade existingTrade = tradeRepository.getTradeByTradeId(trade.getTradeId());
        if (existingTrade != null && existingTrade.getTradeId().equals(trade.getTradeId())) {
            if (trade.getVersion() < existingTrade.getVersion()) {
                // Reject the trade and throw an exception for
                throw new Exception(TRADE_REJECTED_VERSION_EXCEPTION);
            } else if (trade.getVersion() >= existingTrade.getVersion()) {
                tradeResponse = tradeRepository.createTrade(trade);
            }
        }

        // Validation for Maturity Date
        if (trade.getMaturityDate().isBefore(LocalDate.now()) || trade.getMaturityDate().isEqual(LocalDate.now())) {
            // Reject the trade and throw an exception for less maturity date
            throw new Exception(TRADE_REJECTED_MATURITY_DATE_EXCEPTION);
        }

        /**
         * Validation for updating the expiry flag if the trade crosses the maturity date
         */
        if (existingTrade != null && existingTrade.getMaturityDate().isBefore(LocalDate.now())) {
            existingTrade.setExpired(true);
            tradeResponse = tradeRepository.createTrade(existingTrade);
        }
        return tradeResponse;
    }

    @Override
    public Optional<Trade> getTradeByTradeId(String tradeId) {
        return Optional.ofNullable(tradeRepository.getTradeByTradeId(tradeId));
    }

}
