package com.db.trade.constants;

/**
 * @author R.Hadke
 */
public class MongoDbConstants {

    public static final String TRADE_COLLECTION = "trade";
}
